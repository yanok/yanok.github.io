import java.util.List;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

abstract class AstNode {
  Location _loc;
  public AstNode(ParserRuleContext ctx) {
    _loc = new Location(ctx);
  }
  abstract Object accept(Visitor visitor);
}

class Program extends AstNode {
  FunDefListHead _raw;
  List<FunDef> _functions;
  Program(ParserRuleContext ctx, FunDefListHead raw) {
    super(ctx); _raw = raw; _functions = null;
  }
  Object accept(Visitor visitor) { return visitor.visit(this); }
}

class FunDef extends AstNode {
  FunId _name;
  FunDef(ParserRuleContext ctx, FunId name) { super(ctx); _name = name; }
  Object accept(Visitor visitor) { return visitor.visit(this); }
}

class FunDefListHead extends AstNode {
  FunDef _first;
  FunDefListTail _tail;
  FunDefListHead(ParserRuleContext ctx) { super(ctx); _first = null; _tail = null; }
  FunDefListHead(ParserRuleContext ctx, FunDef first, FunDefListTail tail) {
    super(ctx); _first = first; _tail = tail;
  }
  Object accept(Visitor visitor) { return visitor.visit(this); }
}

class FunDefListTail extends AstNode {
  List<FunDef> _inh;
  FunDef _next;
  FunDefListTail _tail;
  FunDefListTail(ParserRuleContext ctx) { super(ctx); _next = null; _tail = null; }
  FunDefListTail(ParserRuleContext ctx,FunDef next,FunDefListTail tail) {
    super(ctx); _next = next; _tail = tail;
  }
  Object accept(Visitor visitor) { return visitor.visit(this); }
}

class FunId extends AstNode {
  String _id;
  FunId(ParserRuleContext ctx, String id) { super(ctx); _id = id; }
  Object accept(Visitor visitor) { return visitor.visit(this); }
}
