import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class Location {
  public Location(ParserRuleContext ctx) {
    /* get location info from context */
  }
}
