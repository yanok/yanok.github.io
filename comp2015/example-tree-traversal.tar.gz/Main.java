import java.io.PrintWriter;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

class Main {
  public static void main(final String[] args) {
    String fileName = args[0];
    ExampleLexer lexer = null;
    try {
      lexer = new ExampleLexer(new ANTLRFileStream(fileName));
    }
    catch (Throwable e) {
      System.out.println("Error " + e.getMessage());
      e.printStackTrace();
    }
    final ExampleParser parser = new ExampleParser(new CommonTokenStream(lexer));
    final AstNode rawAst = parser.program().r;
    final PrintWriter writer = new PrintWriter(System.out, true);
    final SyntaxTreePrinter syntaxTreePrinter = new SyntaxTreePrinter(writer);
    System.out.println("--- Raw AST ----");
    rawAst.accept(syntaxTreePrinter);
    final TreeNormalizer normalizer = new TreeNormalizer();
    final AstNode ast = (AstNode)rawAst.accept(normalizer);
    System.out.println("--- Normalized AST ----");
    ast.accept(syntaxTreePrinter);
  }
}
